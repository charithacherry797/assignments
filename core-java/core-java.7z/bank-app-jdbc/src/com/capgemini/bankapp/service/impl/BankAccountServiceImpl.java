package com.capgemini.bankapp.service.impl;

import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.bankapp.dao.BankAccountDao;
import com.capgemini.bankapp.dao.impl.BankAccountDaoImpl;
import com.capgemini.bankapp.exception.BankAccountNotFoundException;
import com.capgemini.bankapp.exception.LowBalanceException;
import com.capgemini.bankapp.model.BankAccount;
import com.capgemini.bankapp.service.BankAccountService;
import com.capgemini.bankapp.util.DbUtil;

public class BankAccountServiceImpl implements BankAccountService {
	static final Logger logger = Logger.getLogger(DbUtil.class);

	private BankAccountDao bankAccountDao;

	public BankAccountServiceImpl() {
		bankAccountDao = new BankAccountDaoImpl();
	}

	
	@Override
	public double checkBalance(long accoundId) throws BankAccountNotFoundException {

		double balance= bankAccountDao.getBalance(accoundId);
		if(balance>=0)
			return balance;
		throw new BankAccountNotFoundException("BankAccount doesn't exist..");
	}

	@Override
	public double withdraw(long accoundId, double amount) throws LowBalanceException, BankAccountNotFoundException {
		double balance = bankAccountDao.getBalance(accoundId);
		if(balance<0)
			throw new BankAccountNotFoundException("BankAccount doesn't exist..");
		else if (balance - amount >= 0) {
			balance = balance - amount;
			bankAccountDao.updateBalance(accoundId, balance);
			DbUtil.commit();
			return balance;
		} else
			throw new LowBalanceException("You don't have sufficient fund...");

	}
	@Override
	public double withdrawForFundTransfer(long accoundId, double amount) throws LowBalanceException, BankAccountNotFoundException {
		double balance = bankAccountDao.getBalance(accoundId);
		if(balance<0)
			throw new BankAccountNotFoundException("BankAccount doesn't exist..");
		else if (balance - amount >= 0) {
			balance = balance - amount;
			bankAccountDao.updateBalance(accoundId, balance);
			DbUtil.commit();
			return balance;
		} else
			throw new LowBalanceException("You don't have sufficient fund...");

	}

	@Override
	public double deposite(long accountId, double amount) throws BankAccountNotFoundException {
		double balance = bankAccountDao.getBalance(accountId);
		if(balance<0)
			throw new BankAccountNotFoundException("BankAccount doesn't exist..");
		balance = balance + amount;
		bankAccountDao.updateBalance(accountId, balance);
		DbUtil.commit();
		return balance;
	}

	@Override
	public boolean deleteBankAccount(long accountId) throws BankAccountNotFoundException {
		boolean result =  bankAccountDao.deleteBankAccount(accountId);
		if(result) {
			DbUtil.commit();
			return result;
		
		}
		throw new BankAccountNotFoundException("BankAcccount doesn't exist..");
	}
	@Override
	public double fundTransfer(long fromAccount, long toAccount, double amount) throws LowBalanceException, BankAccountNotFoundException {
		
		try {
		double newBalance = withdrawForFundTransfer(fromAccount, amount);
		deposite(toAccount, amount);
		DbUtil.commit();
		return newBalance;
	}	
		catch(LowBalanceException |BankAccountNotFoundException e) {
			logger.error("Expection ",e);
			DbUtil.rollback();
			throw e;
		}
			
		}
	

	@Override
	public boolean addNewBankAccount(BankAccount account) {
		boolean result = bankAccountDao.addNewBankAccount(account);
		if(result)
			DbUtil.commit();
		return result;
	}

	@Override
	public List<BankAccount> findAllBankAccounts() {
		return bankAccountDao.findAllBankAccounts();
	}

	@Override
	public BankAccount searchBankAccount(long accountId) throws BankAccountNotFoundException {
		BankAccount account= bankAccountDao.searchBankAccount(accountId);
		if(account != null)
			return account;
		
	throw new BankAccountNotFoundException("BankAcccount doesn't exist..");
	}


	@Override
	public boolean updateBankAccountDetails(long accountId,String newName, String newType) {
	if(bankAccountDao.updateBankAccountDetails(accountId,newName, newType)) {
		DbUtil.commit();
		return true;
	}
		else 
			return false;
		}
			
		
	}

	

		
	



