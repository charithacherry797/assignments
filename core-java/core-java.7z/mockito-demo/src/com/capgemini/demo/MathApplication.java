package com.capgemini.demo;

import com.capgemini.demo.exception.InvalidException;
import com.capgemini.demo.service.CaculatorService;

public class MathApplication {
	private CaculatorService service;

	public MathApplication(CaculatorService service) {
		
		this.service = service;
	}
	public int performAddition(int number1,int number2) {
		return service.addition(number1, number2);
		
	}
	public int performSubtaraction(int number1,int number2) {
		return service.subtaraction(number1, number2);
		
	}
	public int performMultiplication(int number1,int number2) {
		return service.multiplication(number1, number2);
		
	}
	public double performDivision(int number1,int number2) {
		return service.division(number1, number2);
		
	}
public long findFactorial(int number) throws InvalidException {
	return service.factorial(number);
}
public long findSquare(int number) {
	return service.square(number);
}

}
