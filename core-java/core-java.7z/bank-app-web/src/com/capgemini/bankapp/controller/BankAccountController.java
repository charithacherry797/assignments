package com.capgemini.bankapp.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.bankapp.exception.BankAccountNotFoundException;
import com.capgemini.bankapp.exception.LowBalanceException;
import com.capgemini.bankapp.model.BankAccount;
import com.capgemini.bankapp.service.BankAccountService;
import com.capgemini.bankapp.service.impl.BankAccountServiceImpl;

@WebServlet(urlPatterns = { "*.do" }, loadOnStartup = 1)
public class BankAccountController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private BankAccountService bankService;

	public BankAccountController() {
		bankService = new BankAccountServiceImpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		String path = request.getServletPath();
		if (path.equals("/all accounts.do")) {
			List<BankAccount> bankAccounts = bankService.findAllBankAccounts();
			RequestDispatcher dispatcher = request.getRequestDispatcher("all accounts.jsp");
			request.setAttribute("accounts", bankAccounts);
			dispatcher.forward(request, response);
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String path = request.getServletPath();
		System.out.println(path);
		if (path.equals("/addNewBankAccount.do")) {
			String accountHolderName = request.getParameter("Customer name");
			String accountType = request.getParameter("Account Type");
			double balance = Double.parseDouble(request.getParameter("Account Balance"));

			BankAccount account = new BankAccount(accountHolderName, accountType, balance);
			if (bankService.addNewBankAccount(account)) {
				out.println("<h2>BankAccount is Created successfully..");
				out.println("<h2><a href='index.html'>|Home|</h2>");
				out.close();

			}
		}

		if (path.equals("/addWithDraw.do")) {
			long accountId = Long.parseLong(request.getParameter("AccountId"));
			double balance = Double.parseDouble(request.getParameter("Amount"));
			try {

				bankService.withdraw(accountId, balance);
				out.println("<h2>your amount is debited..");
				out.close();
			} catch (LowBalanceException e) {
				out.println("<h2>low balance exception..");
				out.println("<h2><a href='index.html'>|Home|</h2>");
			} catch (BankAccountNotFoundException e) {
				out.println("<h2>bank account not found exception..");
				out.println("<h2><a href='index.html'>|Home|</h2>");
			}

		}
		if (path.equals("/addFundTransfer.do")) {
			long fromAccountId = Long.parseLong(request.getParameter("from account"));
			long toAccountId = Long.parseLong(request.getParameter("to account"));
			double balance = Double.parseDouble(request.getParameter("Amount"));
			try {
				bankService.fundTransfer(fromAccountId, toAccountId, balance);
				out.println("<h2>your amount is credited..");
				out.close();
			} catch (LowBalanceException e) {
				out.println("<h2>low balance exception..");
				out.println("<h2><a href='index.html'>|Home|</h2>");
			} catch (BankAccountNotFoundException e) {
				out.println("<h2>bank account not found exception..");
				out.println("<h2><a href='index.html'>|Home|</h2>");
			}

		}
		if (path.equals("/addDeposit.do")) {
			long accountId = Long.parseLong(request.getParameter("AccountId"));
			double balance = Double.parseDouble(request.getParameter("Amount"));
			try {

				bankService.deposite(accountId, balance);
				out.println("<h2>your amount is debited..");
				out.println("<h2><a href='index.html'>|Home|</h2>");
				out.close();
			}

			catch (BankAccountNotFoundException e) {
				out.println("<h2>bank account not found exception..");
				out.println("<h2><a href='index.html'>|Home|</h2>");
			}

		}
		if (path.equals("/addDelete.do")) {
			long accountId = Long.parseLong(request.getParameter("accountId"));
			try {

				bankService.deleteBankAccount(accountId);
				out.println("<h2>your account deleted successfully..");
				out.close();
			} catch (BankAccountNotFoundException e) {
				out.println("<h2>bank account not found exception..");
				out.println("<h2><a href='index.html'>|Home|</h2>");
			}

		}
		if (path.equals("/addCheckBalance.do")) {
			long accountId = Long.parseLong(request.getParameter("accountId"));
			try {

				bankService.checkBalance(accountId);
				out.println("<h2>your account check successfully..");
				out.close();
			} catch (BankAccountNotFoundException e) {
				out.println("<h2>bank account not found exception..");
				out.println("<h2><a href='index.html'>|Home|</h2>");
			}
		}
		if (path.equals("/searchAccount.do")) {
			long accountId = Long.parseLong(request.getParameter("accountId"));
			try {
				BankAccount bankAccounts = bankService.searchBankAccount(accountId);
				RequestDispatcher dispatcher = request.getRequestDispatcher("searchAccount.jsp");
				request.setAttribute("account", bankAccounts);
				dispatcher.forward(request, response);
			} catch (BankAccountNotFoundException e) {
				out.println("<h2>bank account not found exception..");
				out.println("<h2><a href='index.html'>|Home|</h2>");
			}
			out.close();
		}
		if (path.equals("/detailstoupdate.do")) {
			long accountId = Long.parseLong(request.getParameter("accountId"));
			try {
				BankAccount bankAccounts = bankService.searchBankAccount(accountId);
				RequestDispatcher dispatcher = request.getRequestDispatcher("updateBankAccountDetails.jsp");
				request.setAttribute("account", bankAccounts);
				dispatcher.forward(request, response);

			} catch (BankAccountNotFoundException e) {
				out.println("<h2>bank account not found exception..");
				out.println("<h2><a href='index.html'>|Home|</h2>");
			}
			out.close();

		}
		if (path.equals("/updatedetails.do")) {
			long accountId = Long.parseLong(request.getParameter("accountId"));
			String accountHolderName = request.getParameter("customername");
			String accountType = request.getParameter("accounttype");
			
			if(bankService.updateBankAccountDetails(accountId,accountHolderName, accountType)) {
				out.println("<h2>bank account updated");
			}
			else
				out.println("<h2>bank account not updated..");
		
		}
	}
}
