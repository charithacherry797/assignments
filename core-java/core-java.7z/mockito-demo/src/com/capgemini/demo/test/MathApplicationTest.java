package com.capgemini.demo.test;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.capgemini.demo.MathApplication;
import com.capgemini.demo.exception.InvalidException;
import com.capgemini.demo.service.CaculatorService;

public class MathApplicationTest {
	@Mock
	private CaculatorService service;
	@InjectMocks
	MathApplication application = new MathApplication(service);

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testPerformAdditionWithTwoPositiveInteger() {
		when(service.addition(6, 4)).thenReturn(10);
		assertEquals(10, application.performAddition(6, 4));
	}

	@Test
	public void testPerformAdditionTwoNegativeInteger() {
		when(service.addition(-6, -4)).thenReturn(-10);
		assertEquals(-10, application.performAddition(-6, -4));
	}

	@Test
	public void testPeformAdditionBothPositiveAndNegative() {
		when(service.addition(-6, 4)).thenReturn(-2);
		assertEquals(-2, application.performAddition(-6, 4));

	}

	@Test
	public void testPerformSubtaractionWithTwoPositiveInteger() {
		when(service.subtaraction(6, 4)).thenReturn(2);
		assertEquals(2, application.performSubtaraction(6, 4));
	}

	@Test
	public void testPerformSubtaractionWithTwoNegativeInteger() {
		when(service.subtaraction(-6, -4)).thenReturn(-10);
		assertEquals(-10, application.performSubtaraction(-6, -4));
	}

	@Test
	public void testPeformSubtaractionBothPositiveAndNegative() {
		when(service.subtaraction(-6, 4)).thenReturn(-2);
		assertEquals(-2, application.performSubtaraction(-6, 4));

	}

	@Test
	public void testPerformMultiplicationWithTwoPositiveInteger() {
		when(service.multiplication(6, 4)).thenReturn(24);
		assertEquals(24, application.performMultiplication(6, 4));
	}

	@Test
	public void testPerformMultiplicationWithTwoNegativeInteger() {
		when(service.multiplication(-6, -4)).thenReturn(24);
		assertEquals(24, application.performMultiplication(-6, -4));
	}

	@Test
	public void testPerformMultiplicationBothPositiveAndNegative() {
		when(service.multiplication(6, -4)).thenReturn(-24);
		assertEquals(-24, application.performMultiplication(6, -4));
	}

	@Test(expected = ArithmeticException.class)
	public void testPerformDivisionWithDivisorZero() {
		doThrow(new ArithmeticException("/ by zero")).when(service).division(10, 0);
		application.performDivision(10, 0);
	}
	@Test
	public void testPeformDivisionWithTwoPositiveInteger() {
		when(service.division(6, 4)).thenReturn(1.5);
		assertEquals(1.5, application.performDivision(6, 4),0.01);
	}
	

	@Test
	public void testFindFactorialWithPositiveInteger() throws InvalidException {
		when(service.factorial(5)).thenReturn(120L);
		assertEquals(120, application.findFactorial(5));
	}
	@Test(expected = InvalidException.class)
	public void testPeformFactorialWithNegativeInteger() throws InvalidException {
		doThrow(new InvalidException("negative number")).when(service).factorial(-5);
		application.findFactorial(-5);
	}
	@Test
	public void testPeformSquareWithTwoPositiveInteger() {
		when(service.square(6)).thenReturn(36L);
		assertEquals(36, application.findSquare(6));
	}
	@Test
	public void testPeformSquareWithTwoNegativeInteger() {
		when(service.square(-6)).thenReturn(36L);
		assertEquals(36, application.findSquare(-6));
	}
}
