package com.capgemini.bankapp.exception;

public class DebitLimitExceedsException extends Exception {

	public DebitLimitExceedsException(String string) {
		super(string);
	}

}
