package com.capgemini.demo.service;

import com.capgemini.demo.exception.InvalidException;

public interface CaculatorService {
	public int addition(int number1, int number2);

	public int subtaraction(int number1, int number2);

	public int multiplication(int number1, int number2);

	public double division(int number1, int number2);

	public long factorial(int number) throws InvalidException;

	public long square(int number);

}
