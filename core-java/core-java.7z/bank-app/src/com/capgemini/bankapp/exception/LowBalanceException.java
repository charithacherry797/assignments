package com.capgemini.bankapp.exception;

public class LowBalanceException extends Exception {

	public LowBalanceException(String string) {
		super(string);
	}

}
